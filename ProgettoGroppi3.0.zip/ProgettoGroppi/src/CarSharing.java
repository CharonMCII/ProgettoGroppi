import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.junit.Test;

public class CarSharing {
    private List<Parcheggio> parcheggi = new ArrayList<>();
    private List<Automobile> automobili = new ArrayList<>();

// metodo aggiungi parcheggio
    public void aggiungiParcheggio(Parcheggio parcheggio) {
        if (!parcheggi.contains(parcheggio)) {
            parcheggi.add(parcheggio);
        }
    }

// metodo aggiungi autombile
    public void aggiungiAutomobile(Automobile automobile) {
        if (!automobili.contains(automobile)) {
            if (!parcheggi.contains(automobile.getLocazione())) {
                parcheggi.add(automobile.getLocazione());
            }
            automobili.add(automobile);
        }
    }
// metodo transito (ovvero i viaggi che ha fatto la macchina)
    public void transito(Automobile automobile, Parcheggio nuovoParcheggio) {
        automobile.setViaggi(automobile.getViaggi() + 1);
        automobile.setLocazione(nuovoParcheggio);
    }
// metodo conta automobile nel parcheggio 
    public int contaAutomobili(Parcheggio parcheggio) {
        int count = 0;
        Iterator<Automobile> iterator = automobili.iterator();
        while (iterator.hasNext()) {
            Automobile automobile = iterator.next();
            if (automobile.getLocazione().equals(parcheggio)) {
                count++;
            }
        }
        return count;
    }
// metodo che rimuove le automobili
    public void rimuoviAutomobili(int viaggiMinimi) {
        Iterator<Automobile> iterator = automobili.iterator();
        while (iterator.hasNext()) {
            Automobile automobile = iterator.next();
            if (automobile.getViaggi() >= viaggiMinimi) {
                iterator.remove();
            }
        }
    }
    
    
    public void salvaDatiSuFile(String nomeFile) {
        try (FileWriter writer = new FileWriter(nomeFile)) {
            for (Parcheggio parcheggio : parcheggi) {
                writer.write("Parcheggio: " + parcheggio.getNome() + "\n");
                writer.write("Macchine presenti:\n");
                for (Automobile automobile : automobili) {
                    if (automobile.getLocazione().equals(parcheggio)) {
                    	writer.write("\n");
                    	writer.write(" Modello Macchina: " + automobile.getNome() + "\n");
                        writer.write(" Targa: " + automobile.getTarga() + "\n");
                        
                    }
                }
                writer.write("\n");
            }
            writer.close();
            System.out.println("Dati salvati su file: " + nomeFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
