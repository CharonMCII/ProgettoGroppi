public class Automobile {
    private String targa;
    private int viaggi;
    private Parcheggio locazione;
    private String nome;

    // creazione classe automobile
    public Automobile(String targa, Parcheggio locazione, String nome) {
        this.targa = targa;
        this.viaggi = 0;
        this.locazione = locazione;
        this.nome = nome;
    }

    public String getTarga() {
        return targa;
    }

    public int getViaggi() {
        return viaggi;
    }

    public void setViaggi(int viaggi) {
        this.viaggi = viaggi;
    }

    public Parcheggio getLocazione() {
        return locazione;
    }

    public void setLocazione(Parcheggio locazione) {
        this.locazione = locazione;
    }
    
    public String getNome()
    {
    	return nome;
    }
}