import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class Main {

    public static void main(String[] args) {
		
		// creazione di due parcheggi
        Parcheggio parcheggio1 = new Parcheggio("Parcheggio 1");
        Parcheggio parcheggio2 = new Parcheggio("Parcheggio 2");

		// creazione di automobili
        Automobile automobile1 = new Automobile("AXCFEEG", parcheggio1, "Chaser");
        Automobile automobile2 = new Automobile("HK45JOK", parcheggio2, "Supra");
        Automobile automobile3 = new Automobile("LMNAUO9", parcheggio1, "RX-7");

		// assegnazione delle automobili nei parcheggi
        CarSharing carSharing = new CarSharing();
        carSharing.aggiungiParcheggio(parcheggio1);
        carSharing.aggiungiParcheggio(parcheggio2);

        carSharing.aggiungiAutomobile(automobile1);
        carSharing.aggiungiAutomobile(automobile2);
        carSharing.aggiungiAutomobile(automobile3);

        // Salva i dati su un file di testo
        carSharing.salvaDatiSuFile("carsharing_data.txt");
        
        // Stampa delle macchine presenti nel parcheggio1
        System.out.println("Nel parcheggio " + parcheggio1.getNome() + " ci sono: " + carSharing.contaAutomobili(parcheggio1) + " macchine");
    }
}
