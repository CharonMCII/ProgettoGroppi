import java.util.ArrayList;
import java.util.List;

public class Parcheggio {
    private String nome;

    public Parcheggio(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }
}